/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iterator_atividade;

/**
 *
 * @author rehri
 */
public class Iterator_Atividade {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
           EstoqueRoupas nomes = new EstoqueRoupas();
		System.out.println("Iterando com laço de repetição:");
		for (IteratorRoupas it = nomes.criarIterator(); !it.isDone(); it
				.proximaroupa()) {
			System.out.println(it.getroupa());
		}

		System.out.println("\nIterando de forma manual:");
		IteratorRoupas it = nomes.criarIterator();
		System.out.println(it.getroupa());
		it.proximaroupa();
		System.out.println(it.getroupa());
		it.proximaroupa();
		System.out.println(it.getroupa());
		it.proximaroupa();
		System.out.println(it.getroupa());
		it.proximaroupa();
		System.out.println(it.getroupa());

		System.out.println("\nIterando fora dos limites:");
		it.proximaroupa();
		System.out.println(it.getroupa());
		it.first();
		it.voltarroupa();
		System.out.println(it.getroupa());
    }
    
}
