/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iterator_atividade;

/**
 *
 * @author rehri
 */
public class Roupas {
       String estoque;

    public Roupas(String estoque) {
        this.estoque = estoque;
    }
}
