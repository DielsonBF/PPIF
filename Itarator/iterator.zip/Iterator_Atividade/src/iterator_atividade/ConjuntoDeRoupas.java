/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iterator_atividade;

import java.util.ArrayList;

/**
 *
 * @author rehri
 */
public abstract class ConjuntoDeRoupas {
       protected ArrayList<Roupas> estoque;

    public ConjuntoDeRoupas() {
        estoque = new ArrayList<Roupas>();
    }

    public int count() {
        return estoque.size();
    }

    public IteratorRoupas criarIterator() {
        return new IteratorRoupas(estoque);
    }
}
