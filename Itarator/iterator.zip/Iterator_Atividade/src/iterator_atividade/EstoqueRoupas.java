/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iterator_atividade;

/**
 *
 * @author rehri
 */
public class EstoqueRoupas extends ConjuntoDeRoupas{
      public EstoqueRoupas() {
        estoque.add(new Roupas("Nike"));
        estoque.add(new Roupas("Adidas "));
        estoque.add(new Roupas("Polo  "));
        estoque.add(new Roupas("Lacoste  "));
        estoque.add(new Roupas(" Pena"));
       
    }
}
